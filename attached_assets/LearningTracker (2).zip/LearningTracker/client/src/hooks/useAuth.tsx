import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

// Define the User type
interface User {
  id: number;
  username: string;
  firstName: string | null;
  lastName: string | null;
  role: string;
}

// Define the AuthContext type
interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string, firstName: string, lastName: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

// Create the context
const AuthContext = createContext<AuthContextType | null>(null);

// Create the provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  const [, setLocation] = useLocation();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Our test accounts with passwords
  const testAccounts = {
    "admin@edulearn.com": {
      id: 1,
      username: "admin@edulearn.com",
      firstName: "Admin",
      lastName: "User",
      role: "admin",
      password: "password"
    },
    "john@example.com": {
      id: 2,
      username: "john@example.com",
      firstName: "John",
      lastName: "Smith",
      role: "student",
      password: "password"
    }
  };

  // Check if user is already logged in on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("lms_user");
    
    if (storedUser) {
      try {
        const userData = JSON.parse(storedUser);
        setUser(userData);
        console.log("User restored from localStorage:", userData);
      } catch (error) {
        console.error("Error parsing stored user data:", error);
        localStorage.removeItem("lms_user");
      }
    }
    
    setLoading(false);
  }, []);

  // Computed properties
  const isAuthenticated = !!user;
  const isAdmin = user?.role === "admin";

  // Login function
  const login = async (username: string, password: string) => {
    console.log("Login attempt:", username);
    
    // First check our hardcoded test accounts
    const testAccount = testAccounts[username];
    
    if (testAccount && testAccount.password === password) {
      // Create a user object without the password
      const loggedInUser = {
        id: testAccount.id,
        username: testAccount.username,
        firstName: testAccount.firstName,
        lastName: testAccount.lastName,
        role: testAccount.role
      };
      
      // Save to state and localStorage
      setUser(loggedInUser);
      localStorage.setItem("lms_user", JSON.stringify(loggedInUser));
      
      // Success notification
      toast({
        title: "Login successful",
        description: `Welcome back, ${loggedInUser.firstName || username}!`,
      });
      
      console.log("Login successful, user:", loggedInUser);
      
      // Navigate to dashboard
      console.log("Navigating to dashboard");
      setLocation("/dashboard");
      return;
    }
    
    // Check localStorage for registered users
    const registeredUsers = JSON.parse(localStorage.getItem("lms_registered_users") || "{}");
    const registeredUser = registeredUsers[username];
    
    if (registeredUser && registeredUser.password === password) {
      // Create a user object without the password
      const loggedInUser = {
        id: registeredUser.id,
        username: registeredUser.username,
        firstName: registeredUser.firstName,
        lastName: registeredUser.lastName,
        role: registeredUser.role
      };
      
      // Save to state and localStorage
      setUser(loggedInUser);
      localStorage.setItem("lms_user", JSON.stringify(loggedInUser));
      
      // Success notification
      toast({
        title: "Login successful",
        description: `Welcome back, ${loggedInUser.firstName || username}!`,
      });
      
      console.log("Login successful for registered user:", loggedInUser);
      
      // Navigate to dashboard
      console.log("Navigating to dashboard");
      setLocation("/dashboard");
      return;
    }
    
    // If we get here, login failed
    console.error("Login failed: Invalid credentials");
    toast({
      title: "Login failed",
      description: "Invalid username or password.",
      variant: "destructive",
    });
    
    throw new Error("Invalid credentials");
  };

  // Register function
  const register = async (username: string, password: string, firstName: string, lastName: string) => {
    console.log("Registration attempt:", username);
    
    // Check if user already exists
    if (testAccounts[username]) {
      toast({
        title: "Registration failed",
        description: "An account with this email already exists.",
        variant: "destructive",
      });
      throw new Error("User already exists");
    }
    
    // Get existing registered users
    const registeredUsers = JSON.parse(localStorage.getItem("lms_registered_users") || "{}");
    
    if (registeredUsers[username]) {
      toast({
        title: "Registration failed",
        description: "An account with this email already exists.",
        variant: "destructive",
      });
      throw new Error("User already exists");
    }
    
    // Create new user
    const newUser = {
      id: Date.now(),
      username,
      firstName,
      lastName,
      role: "student",
      password
    };
    
    // Save to registered users in localStorage
    registeredUsers[username] = newUser;
    localStorage.setItem("lms_registered_users", JSON.stringify(registeredUsers));
    
    // Success notification
    toast({
      title: "Registration successful",
      description: "Please log in with your new account.",
    });
    
    console.log("Registration successful:", username);
    
    // Redirect to login
    setLocation("/auth");
  };

  // Logout function
  const logout = () => {
    setUser(null);
    localStorage.removeItem("lms_user");
    
    toast({
      title: "Logged out",
      description: "You have been logged out successfully.",
    });
    
    setLocation("/auth");
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        register,
        logout,
        isAuthenticated,
        isAdmin
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook to use the auth context
export function useAuth() {
  const context = useContext(AuthContext);
  
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  
  return context;
}