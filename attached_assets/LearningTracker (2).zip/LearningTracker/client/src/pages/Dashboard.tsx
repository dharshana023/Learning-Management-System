import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import CourseCard from "@/components/CourseCard";
import StatCard from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import {
  BookOpen,
  CheckCircle,
  Clock,
  Award,
  Loader2,
  PlusCircle
} from "lucide-react";

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user } = useAuth();
  
  // Fetch enrolled courses
  const { data: enrollments, isLoading } = useQuery({
    queryKey: ["/api/enrollments"],
  });
  
  // Calculate dashboard stats
  const totalEnrolled = enrollments?.length || 0;
  const totalCompleted = enrollments?.filter(e => e.isCompleted).length || 0;
  const totalLearningHours = enrollments ? Math.round(totalEnrolled * 6.5) : 0; // Rough estimate
  const totalCertificates = enrollments?.filter(e => e.isCompleted).length || 0;
  
  // Fetch recommended courses
  const { data: recommendedCourses, isLoading: isLoadingRecommended } = useQuery({
    queryKey: ["/api/courses"],
  });
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <div className="flex min-h-screen bg-neutral-100">
      <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 ml-0 md:ml-64 min-h-screen">
        <Header toggleSidebar={toggleSidebar} />
        
        <div className="p-6">
          {/* Welcome Section */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
            <div>
              <h1 className="text-2xl font-semibold text-neutral-900">
                Welcome back, {user?.firstName || "Student"}! 👋
              </h1>
              <p className="text-neutral-600 mt-1">
                Ready to continue your learning journey?
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <Link href="/courses">
                <Button className="flex items-center">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Enroll in New Course
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard
              icon={<BookOpen className="h-5 w-5" />}
              iconBgColor="bg-blue-100"
              iconColor="text-primary-600"
              title="Enrolled Courses"
              value={totalEnrolled}
            />
            
            <StatCard
              icon={<CheckCircle className="h-5 w-5" />}
              iconBgColor="bg-green-100"
              iconColor="text-green-600"
              title="Completed Courses"
              value={totalCompleted}
            />
            
            <StatCard
              icon={<Clock className="h-5 w-5" />}
              iconBgColor="bg-orange-100"
              iconColor="text-orange-600"
              title="Learning Hours"
              value={`${totalLearningHours}h`}
            />
            
            <StatCard
              icon={<Award className="h-5 w-5" />}
              iconBgColor="bg-yellow-100"
              iconColor="text-yellow-600"
              title="Certificates"
              value={totalCertificates}
            />
          </div>
          
          {/* Continue Learning Section */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-neutral-900 mb-4">
              Continue Learning
            </h2>
            
            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 text-primary animate-spin" />
              </div>
            ) : enrollments && enrollments.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {enrollments.slice(0, 3).map((enrollment) => (
                  <CourseCard
                    key={enrollment.id}
                    course={enrollment.course}
                    progress={enrollment.progress}
                    isEnrolled={true}
                    isCompleted={enrollment.isCompleted}
                  />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow p-8 text-center">
                <h3 className="font-medium text-lg mb-2">
                  You haven't enrolled in any courses yet
                </h3>
                <p className="text-neutral-600 mb-6">
                  Browse our course catalog to find courses that interest you
                </p>
                <Link href="/courses">
                  <Button>
                    Browse Courses
                  </Button>
                </Link>
              </div>
            )}
          </div>
          
          {/* Certificates Section */}
          {totalCertificates > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-neutral-900 mb-4">
                Your Certificates
              </h2>
              
              <div className="bg-white rounded-lg shadow overflow-hidden">
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <Award className="h-6 w-6 text-yellow-500 mr-3" />
                    <h3 className="text-lg font-medium">
                      Completed Course Certificates
                    </h3>
                  </div>
                  
                  <div className="space-y-4">
                    {enrollments
                      ?.filter(enrollment => enrollment.isCompleted)
                      .map(enrollment => (
                        <div key={enrollment.id} className="flex items-center justify-between border-b pb-4">
                          <div>
                            <p className="font-medium">{enrollment.course.title}</p>
                            <p className="text-sm text-gray-500">Completed on: {new Date().toLocaleDateString()}</p>
                          </div>
                          <Link href={`/lessons/${enrollment.course.id}`}>
                            <Button variant="outline" size="sm" className="flex items-center">
                              <Award className="mr-2 h-4 w-4 text-yellow-500" />
                              View Certificate
                            </Button>
                          </Link>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Recommended Courses */}
          <div>
            <h2 className="text-xl font-semibold text-neutral-900 mb-4">
              Recommended For You
            </h2>
            
            {isLoadingRecommended ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 text-primary animate-spin" />
              </div>
            ) : recommendedCourses && recommendedCourses.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {recommendedCourses.slice(0, 4).map((course) => (
                  <CourseCard
                    key={course.id}
                    course={course}
                    variant="recommended"
                  />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow p-8 text-center">
                <p className="text-neutral-600">
                  No recommended courses available at the moment.
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
