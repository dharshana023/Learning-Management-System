import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import StatCard from "@/components/StatCard";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Book,
  Users,
  CheckCircle,
  Star,
  Edit,
  Trash2,
  Plus,
  Search,
  Filter,
  ArrowUpDown,
  Loader2,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import CourseImporter from "@/components/CourseImporter";
import { 
  Pagination, 
  PaginationContent, 
  PaginationEllipsis, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from "@/components/ui/pagination";

const courseSchema = z.object({
  title: z.string().min(1, { message: "Title is required" }),
  description: z.string().min(1, { message: "Description is required" }),
  category: z.string().min(1, { message: "Category is required" }),
  level: z.string().min(1, { message: "Level is required" }),
  instructor: z.string().min(1, { message: "Instructor is required" }),
  imageUrl: z.string().url({ message: "Valid image URL is required" }).optional(),
  duration: z.string().min(1, { message: "Duration is required" }),
  lessonsCount: z.coerce.number().min(1, { message: "Lessons count must be at least 1" }),
  price: z.string().min(1, { message: "Price is required" }),
  status: z.string().min(1, { message: "Status is required" })
});

type CourseFormValues = z.infer<typeof courseSchema>;

export default function Admin() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [courseToDelete, setCourseToDelete] = useState<number | null>(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [courseToEdit, setCourseToEdit] = useState<number | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState<{success: boolean; message: string; count: number} | null>(null);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch all courses
  const {
    data: courses,
    isLoading: isLoadingCourses,
  } = useQuery({
    queryKey: ["/api/courses"],
  });

  // Create course form
  const form = useForm<CourseFormValues>({
    resolver: zodResolver(courseSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "Web Development",
      level: "Beginner",
      instructor: "",
      imageUrl: "",
      duration: "",
      lessonsCount: 1,
      price: "",
      status: "published"
    },
  });

  // Create course mutation
  const createCourseMutation = useMutation({
    mutationFn: async (courseData: CourseFormValues) => {
      return apiRequest("POST", "/api/courses", courseData);
    },
    onSuccess: () => {
      toast({
        title: "Course created",
        description: "The course has been created successfully.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create course. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update course mutation
  const updateCourseMutation = useMutation({
    mutationFn: async ({ id, courseData }: { id: number, courseData: CourseFormValues }) => {
      return apiRequest("PUT", `/api/courses/${id}`, courseData);
    },
    onSuccess: () => {
      toast({
        title: "Course updated",
        description: "The course has been updated successfully.",
      });
      setIsEditMode(false);
      setCourseToEdit(null);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update course. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Delete course mutation
  const deleteCourseMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/courses/${id}`, undefined);
    },
    onSuccess: () => {
      toast({
        title: "Course deleted",
        description: "The course has been deleted successfully.",
      });
      setCourseToDelete(null);
      setIsDeleteDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete course. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFormSubmit = (data: CourseFormValues) => {
    if (isEditMode && courseToEdit) {
      updateCourseMutation.mutate({ id: courseToEdit, courseData: data });
    } else {
      createCourseMutation.mutate(data);
    }
  };

  const handleEditCourse = (course: any) => {
    setIsEditMode(true);
    setCourseToEdit(course.id);
    
    form.reset({
      title: course.title,
      description: course.description,
      category: course.category,
      level: course.level,
      instructor: course.instructor,
      imageUrl: course.imageUrl || "",
      duration: course.duration,
      lessonsCount: course.lessonsCount,
      price: course.price,
      status: course.status
    });
  };

  const handleDeleteCourse = (id: number) => {
    setCourseToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  const confirmDeleteCourse = () => {
    if (courseToDelete) {
      deleteCourseMutation.mutate(courseToDelete);
    }
  };

  const cancelEditMode = () => {
    setIsEditMode(false);
    setCourseToEdit(null);
    form.reset();
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  // Filter courses based on search term
  const filteredCourses = courses ? courses.filter(course => 
    course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.instructor.toLowerCase().includes(searchTerm.toLowerCase())
  ) : [];

  // Calculate admin stats
  const totalCourses = courses?.length || 0;
  const totalStudents = 1254; // This would typically come from an API
  const courseCompletions = 768; // This would typically come from an API
  const avgRating = courses && courses.length > 0 
    ? (courses.reduce((acc, course) => acc + parseFloat(course.rating), 0) / courses.length).toFixed(1)
    : "0.0";

  return (
    <div className="flex min-h-screen bg-neutral-100">
      <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 ml-0 md:ml-64 min-h-screen">
        <Header toggleSidebar={toggleSidebar} />
        
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
            <div>
              <h1 className="text-2xl font-semibold text-neutral-900">Admin Dashboard</h1>
              <p className="text-neutral-600 mt-1">Manage courses, users, and content</p>
            </div>
            <div className="mt-4 md:mt-0">
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="flex items-center">
                    <Plus className="mr-2 h-4 w-4" />
                    Create New Course
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>{isEditMode ? "Edit Course" : "Create New Course"}</DialogTitle>
                    <DialogDescription>
                      {isEditMode 
                        ? "Update the course details below and save your changes."
                        : "Fill in the course details below to create a new course."
                      }
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-6">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="title"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Course Title</FormLabel>
                              <FormControl>
                                <Input placeholder="Web Development Fundamentals" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="instructor"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Instructor</FormLabel>
                              <FormControl>
                                <Input placeholder="John Doe" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Input placeholder="Learn the core technologies of web development..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="category"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Category</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value || "Web Development"}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select a category" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="Web Development">Web Development</SelectItem>
                                  <SelectItem value="Data Science">Data Science</SelectItem>
                                  <SelectItem value="Design">Design</SelectItem>
                                  <SelectItem value="Business">Business</SelectItem>
                                  <SelectItem value="Marketing">Marketing</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="level"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Level</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value || "Beginner"}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select a level" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="Beginner">Beginner</SelectItem>
                                  <SelectItem value="Intermediate">Intermediate</SelectItem>
                                  <SelectItem value="Advanced">Advanced</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="duration"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Duration</FormLabel>
                              <FormControl>
                                <Input placeholder="8 weeks" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="lessonsCount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Number of Lessons</FormLabel>
                              <FormControl>
                                <Input type="number" min={1} {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="price"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Price</FormLabel>
                              <FormControl>
                                <Input placeholder="$49.99 or Free" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="status"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Status</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value || "published"}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select status" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="published">Published</SelectItem>
                                  <SelectItem value="draft">Draft</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="imageUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Image URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://example.com/image.jpg" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <DialogFooter>
                        {isEditMode && (
                          <Button type="button" variant="outline" onClick={cancelEditMode} className="mr-2">
                            Cancel
                          </Button>
                        )}
                        <Button 
                          type="submit"
                          disabled={createCourseMutation.isPending || updateCourseMutation.isPending}
                        >
                          {(createCourseMutation.isPending || updateCourseMutation.isPending) && 
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          }
                          {isEditMode ? "Save Changes" : "Create Course"}
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
          
          {/* Admin Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard
              icon={<Book className="h-5 w-5" />}
              iconBgColor="bg-blue-100"
              iconColor="text-primary-600"
              title="Total Courses"
              value={totalCourses}
            />
            
            <StatCard
              icon={<Users className="h-5 w-5" />}
              iconBgColor="bg-purple-100"
              iconColor="text-purple-600"
              title="Total Students"
              value={totalStudents}
            />
            
            <StatCard
              icon={<CheckCircle className="h-5 w-5" />}
              iconBgColor="bg-green-100"
              iconColor="text-green-600"
              title="Course Completions"
              value={courseCompletions}
            />
            
            <StatCard
              icon={<Star className="h-5 w-5" />}
              iconBgColor="bg-yellow-100"
              iconColor="text-yellow-600"
              title="Avg. Rating"
              value={`${avgRating}/5`}
            />
          </div>
          
          {/* Admin Tabs */}
          <div className="bg-white rounded-lg shadow-md mb-8">
            <Tabs defaultValue="courses">
              <div className="border-b">
                <TabsList className="w-full justify-start border-b-0 rounded-none h-auto">
                  <TabsTrigger 
                    value="courses"
                    className="data-[state=active]:border-primary-500 data-[state=active]:text-primary-600 border-b-2 border-transparent py-4 px-6 text-sm font-medium rounded-none"
                  >
                    Course Management
                  </TabsTrigger>
                  <TabsTrigger 
                    value="users"
                    className="data-[state=active]:border-primary-500 data-[state=active]:text-primary-600 border-b-2 border-transparent py-4 px-6 text-sm font-medium rounded-none"
                  >
                    User Management
                  </TabsTrigger>
                  <TabsTrigger 
                    value="analytics"
                    className="data-[state=active]:border-primary-500 data-[state=active]:text-primary-600 border-b-2 border-transparent py-4 px-6 text-sm font-medium rounded-none"
                  >
                    Analytics
                  </TabsTrigger>
                  <TabsTrigger 
                    value="settings"
                    className="data-[state=active]:border-primary-500 data-[state=active]:text-primary-600 border-b-2 border-transparent py-4 px-6 text-sm font-medium rounded-none"
                  >
                    Settings
                  </TabsTrigger>
                </TabsList>
              </div>
              
              {/* Course Management Content */}
              <TabsContent value="courses" className="p-6">
                {/* Course Importer Component */}
                <div className="mb-6">
                  <CourseImporter />
                </div>
                
                <div className="flex justify-between items-center mb-6">
                  <div className="relative w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-4 w-4" />
                    <Input 
                      type="text" 
                      className="pl-10 pr-4 py-2"
                      placeholder="Search courses..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button variant="outline" className="flex items-center">
                      <Filter className="mr-2 h-4 w-4" />
                      Filter
                    </Button>
                    <Button variant="outline" className="flex items-center">
                      <ArrowUpDown className="mr-2 h-4 w-4" />
                      Sort
                    </Button>
                  </div>
                </div>
                
                <div className="overflow-x-auto">
                  {isLoadingCourses ? (
                    <div className="flex justify-center py-12">
                      <Loader2 className="h-8 w-8 text-primary animate-spin" />
                    </div>
                  ) : filteredCourses.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Course Name</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Instructor</TableHead>
                          <TableHead>Students</TableHead>
                          <TableHead>Rating</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredCourses.map((course) => (
                          <TableRow key={course.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="h-10 w-10 flex-shrink-0">
                                  <div className={`
                                    h-10 w-10 rounded-md flex items-center justify-center text-${
                                      course.category === "Web Development" ? "blue" : 
                                      course.category === "Data Science" ? "purple" :
                                      course.category === "Design" ? "pink" :
                                      "primary"
                                    }-600 bg-${
                                      course.category === "Web Development" ? "blue" : 
                                      course.category === "Data Science" ? "purple" :
                                      course.category === "Design" ? "pink" :
                                      "primary"
                                    }-100
                                  `}>
                                    {course.category === "Web Development" && <Code className="h-4 w-4" />}
                                    {course.category === "Data Science" && <ChartBar className="h-4 w-4" />}
                                    {course.category === "Design" && <Palette className="h-4 w-4" />}
                                    {!["Web Development", "Data Science", "Design"].includes(course.category) && 
                                      <Book className="h-4 w-4" />
                                    }
                                  </div>
                                </div>
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-neutral-900">{course.title}</div>
                                  <div className="text-sm text-neutral-500">
                                    {course.lessonsCount} lessons • {course.duration}
                                  </div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <span className={`
                                inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                ${course.category === "Web Development" ? "bg-blue-100 text-blue-800" : ""}
                                ${course.category === "Data Science" ? "bg-purple-100 text-purple-800" : ""}
                                ${course.category === "Design" ? "bg-pink-100 text-pink-800" : ""}
                                ${!["Web Development", "Data Science", "Design"].includes(course.category) ? 
                                  "bg-gray-100 text-gray-800" : ""}
                              `}>
                                {course.category}
                              </span>
                            </TableCell>
                            <TableCell className="text-sm text-neutral-500">
                              {course.instructor}
                            </TableCell>
                            <TableCell className="text-sm text-neutral-500">
                              {course.reviewCount}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <span className="text-sm text-neutral-900 mr-1">{course.rating}</span>
                                <Star className="h-4 w-4 text-yellow-500 fill-current" />
                              </div>
                            </TableCell>
                            <TableCell>
                              <span className={`
                                inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                ${course.status === "published" ? "bg-green-100 text-green-800" : ""}
                                ${course.status === "draft" ? "bg-yellow-100 text-yellow-800" : ""}
                              `}>
                                {course.status === "published" ? "Published" : "Draft"}
                              </span>
                            </TableCell>
                            <TableCell className="text-right">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="text-primary-500 hover:text-primary-600"
                                onClick={() => handleEditCourse(course)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="text-neutral-500 hover:text-neutral-600"
                                onClick={() => handleDeleteCourse(course.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-neutral-500">No courses found</p>
                    </div>
                  )}
                </div>
                
                {/* Pagination */}
                {filteredCourses.length > 0 && (
                  <div className="flex justify-between items-center mt-6">
                    <div className="text-sm text-neutral-700">
                      Showing <span className="font-medium">1</span> to <span className="font-medium">{filteredCourses.length}</span> of <span className="font-medium">{filteredCourses.length}</span> results
                    </div>
                    
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious href="#" />
                        </PaginationItem>
                        <PaginationItem>
                          <PaginationLink href="#" isActive>1</PaginationLink>
                        </PaginationItem>
                        <PaginationItem>
                          <PaginationLink href="#">2</PaginationLink>
                        </PaginationItem>
                        <PaginationItem>
                          <PaginationLink href="#">3</PaginationLink>
                        </PaginationItem>
                        <PaginationItem>
                          <PaginationEllipsis />
                        </PaginationItem>
                        <PaginationItem>
                          <PaginationNext href="#" />
                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                )}
              </TabsContent>
              
              {/* User Management Tab (placeholder) */}
              <TabsContent value="users" className="p-6">
                <div className="bg-white p-8 text-center">
                  <h3 className="text-lg font-medium mb-2">User Management</h3>
                  <p className="text-neutral-600">This feature is coming soon.</p>
                </div>
              </TabsContent>
              
              {/* Analytics Tab (placeholder) */}
              <TabsContent value="analytics" className="p-6">
                <div className="bg-white p-8 text-center">
                  <h3 className="text-lg font-medium mb-2">Analytics</h3>
                  <p className="text-neutral-600">This feature is coming soon.</p>
                </div>
              </TabsContent>
              
              {/* Settings Tab (placeholder) */}
              <TabsContent value="settings" className="p-6">
                <div className="bg-white p-8 text-center">
                  <h3 className="text-lg font-medium mb-2">Settings</h3>
                  <p className="text-neutral-600">This feature is coming soon.</p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this course? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 sm:space-x-0">
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={confirmDeleteCourse}
              disabled={deleteCourseMutation.isPending}
            >
              {deleteCourseMutation.isPending && 
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              }
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Helper icons for category identification
function Code(props: any) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <polyline points="16 18 22 12 16 6"></polyline>
      <polyline points="8 6 2 12 8 18"></polyline>
    </svg>
  );
}

function ChartBar(props: any) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <line x1="18" y1="20" x2="18" y2="10"></line>
      <line x1="12" y1="20" x2="12" y2="4"></line>
      <line x1="6" y1="20" x2="6" y2="14"></line>
    </svg>
  );
}

function Palette(props: any) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <circle cx="13.5" cy="6.5" r="2.5"></circle>
      <circle cx="17.5" cy="10.5" r="2.5"></circle>
      <circle cx="8.5" cy="7.5" r="2.5"></circle>
      <circle cx="6.5" cy="12.5" r="2.5"></circle>
      <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"></path>
    </svg>
  );
}
