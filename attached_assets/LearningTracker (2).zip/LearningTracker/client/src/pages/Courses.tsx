import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import CourseCard from "@/components/CourseCard";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Loader2, ChevronLeft, ChevronRight } from "lucide-react";

export default function Courses() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [category, setCategory] = useState("all");
  const [level, setLevel] = useState("all");
  const [price, setPrice] = useState("all");
  const [sortBy, setSortBy] = useState("popular");
  const [searchQuery, setSearchQuery] = useState("");
  
  // Fetch all courses with search and filter parameters
  const {
    data: courses,
    isLoading,
    refetch
  } = useQuery({
    queryKey: ["/api/courses", { category, level, search: searchQuery }],
  });
  
  // Fetch user enrollments to check which courses are already enrolled
  const { data: enrollments } = useQuery({
    queryKey: ["/api/enrollments"],
  });
  
  const isEnrolled = (courseId: number) => {
    return enrollments?.some(e => e.course.id === courseId) || false;
  };
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };
  
  // Sort courses based on selected option
  const sortedCourses = courses ? [...courses].sort((a, b) => {
    if (sortBy === "newest") {
      return b.id - a.id; // Assuming newer courses have higher IDs
    } else if (sortBy === "price-low") {
      const priceA = parseFloat(a.price.replace(/[^0-9.-]+/g, "") || "0");
      const priceB = parseFloat(b.price.replace(/[^0-9.-]+/g, "") || "0");
      return priceA - priceB;
    } else if (sortBy === "price-high") {
      const priceA = parseFloat(a.price.replace(/[^0-9.-]+/g, "") || "0");
      const priceB = parseFloat(b.price.replace(/[^0-9.-]+/g, "") || "0");
      return priceB - priceA;
    } else if (sortBy === "rating") {
      return parseFloat(b.rating) - parseFloat(a.rating);
    }
    // Default: most popular (by review count)
    return b.reviewCount - a.reviewCount;
  }) : [];
  
  // Filter by price, category, and level (if selected)
  const filteredCourses = sortedCourses ? sortedCourses.filter(course => {
    // Apply price filter
    if (price === "free") {
      return course.price === "Free";
    } else if (price === "paid") {
      return course.price !== "Free";
    }
    return true;
  }).filter(course => {
    // Apply category filter
    if (category && category !== "all") {
      return course.category === category;
    }
    return true;
  }).filter(course => {
    // Apply level filter
    if (level && level !== "all") {
      return course.level === level;
    }
    return true;
  }) : [];
  
  return (
    <div className="flex min-h-screen bg-neutral-100">
      <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 ml-0 md:ml-64 min-h-screen">
        <Header toggleSidebar={toggleSidebar} onSearch={handleSearch} />
        
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
            <div>
              <h1 className="text-2xl font-semibold text-neutral-900">Course Catalog</h1>
              <p className="text-neutral-600 mt-1">
                Browse and enroll in our extensive collection of courses
              </p>
            </div>
          </div>
          
          {/* Filter and Sort */}
          <div className="bg-white p-4 rounded-lg shadow mb-6">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex-1 min-w-[200px]">
                <label htmlFor="category-filter" className="block text-sm font-medium text-neutral-700 mb-1">
                  Category
                </label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger id="category-filter">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="Web Development">Web Development</SelectItem>
                      <SelectItem value="Data Science">Data Science</SelectItem>
                      <SelectItem value="Design">Design</SelectItem>
                      <SelectItem value="Business">Business</SelectItem>
                      <SelectItem value="Marketing">Marketing</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex-1 min-w-[200px]">
                <label htmlFor="level-filter" className="block text-sm font-medium text-neutral-700 mb-1">
                  Level
                </label>
                <Select value={level} onValueChange={setLevel}>
                  <SelectTrigger id="level-filter">
                    <SelectValue placeholder="All Levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="Beginner">Beginner</SelectItem>
                      <SelectItem value="Intermediate">Intermediate</SelectItem>
                      <SelectItem value="Advanced">Advanced</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex-1 min-w-[200px]">
                <label htmlFor="price-filter" className="block text-sm font-medium text-neutral-700 mb-1">
                  Price
                </label>
                <Select value={price} onValueChange={setPrice}>
                  <SelectTrigger id="price-filter">
                    <SelectValue placeholder="All Prices" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectItem value="all">All Prices</SelectItem>
                      <SelectItem value="free">Free</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex-1 min-w-[200px]">
                <label htmlFor="sort-by" className="block text-sm font-medium text-neutral-700 mb-1">
                  Sort by
                </label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger id="sort-by">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectItem value="popular">Most Popular</SelectItem>
                      <SelectItem value="newest">Newest</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                      <SelectItem value="rating">Highest Rated</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          {/* Course Grid */}
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 text-primary animate-spin" />
            </div>
          ) : filteredCourses && filteredCourses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {filteredCourses.map((course) => (
                <CourseCard
                  key={course.id}
                  course={course}
                  variant="catalog"
                  isEnrolled={isEnrolled(course.id)}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow p-8 text-center">
              <h3 className="font-medium text-lg mb-2">
                No courses found
              </h3>
              <p className="text-neutral-600">
                Try adjusting your filters or search query
              </p>
            </div>
          )}
          
          {/* Pagination */}
          {filteredCourses && filteredCourses.length > 0 && (
            <div className="flex justify-center mt-8">
              <nav className="inline-flex rounded-md shadow">
                <button className="inline-flex items-center px-4 py-2 rounded-l-md border border-neutral-300 bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
                  <ChevronLeft className="h-4 w-4" />
                </button>
                <button className="inline-flex items-center px-4 py-2 border border-neutral-300 bg-primary-50 text-sm font-medium text-primary-600">
                  1
                </button>
                <button className="inline-flex items-center px-4 py-2 border border-neutral-300 bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
                  2
                </button>
                <button className="inline-flex items-center px-4 py-2 border border-neutral-300 bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
                  3
                </button>
                <span className="inline-flex items-center px-4 py-2 border border-neutral-300 bg-white text-sm font-medium text-neutral-500">
                  ...
                </span>
                <button className="inline-flex items-center px-4 py-2 border border-neutral-300 bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
                  8
                </button>
                <button className="inline-flex items-center px-4 py-2 rounded-r-md border border-neutral-300 bg-white text-sm font-medium text-neutral-500 hover:bg-neutral-50">
                  <ChevronRight className="h-4 w-4" />
                </button>
              </nav>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
