import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import CourseProgress from "@/components/CourseProgress";
import Quiz from "@/components/Quiz";
import Certificate from "@/components/Certificate";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, ArrowLeft, ArrowRight, Play, Award, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Helper function to map course IDs to specific YouTube video IDs
// Get video ID based on course title
function getVideoIdFromTitle(courseTitle: string): string {
  // Full detailed mapping of course titles to YouTube video IDs
  const titleToVideoMap: {[key: string]: string} = {
    // Web Development
    "Web Development Fundamentals": "3JluqTojuME", // HTML, CSS, JS comprehensive intro
    "JavaScript Basics": "W6NZfCO5SIk", // JavaScript for beginners
    "Responsive Web Design": "srvUrASNj0s", // Responsive design techniques
    "Mobile App Development": "0-S5a0eXPoc", // React Native intro
    "React Development": "w7ejDZ8SWv8", // React.js crash course
    "Node.js Development": "TlB_eWDSMt4", // Node.js tutorial
    
    // Data Science & Programming
    "Python Programming Basics": "kqtD5dpn9C8", // Python for beginners
    "Data Science Essentials": "JL_grPUnXzY", // Data science intro
    "SQL Basics": "7S_tz1z_5bA", // MySQL tutorial
    "Machine Learning": "7eh4d6sabA0", // Machine learning fundamentals
    
    // Design
    "UX Design Fundamentals": "c9Wg6Cb_YlU", // UX design principles
    "UX Design Principles": "c9Wg6Cb_YlU", // UX design principles
    "3D Modeling Basics": "9xAumJRKV6A", // Blender 3D basics
    "Video Editing": "msBF8qOqbBs", // Premiere Pro basics
    
    // Marketing
    "Digital Marketing Fundamentals": "jxjftd-Z1Co", // Digital marketing essentials
    "Social Media Marketing": "q30xCsgusDE", // Social media strategies
    "SEO Fundamentals": "UtZGxN5L1lM", // SEO guide
    "Content Creation": "waLZRJnW5X8", // Content marketing
    
    // IT & Technology
    "Cloud Computing": "M988_fsOSWo", // AWS basics
    "Cybersecurity Fundamentals": "inWWhr5tnEA", // Cybersecurity intro
    "Introduction to Blockchain": "SSo_EIwHSd4", // Blockchain explained
    "Introduction to Artificial Intelligence": "JMUxmLyrhSk", // AI overview
    "AI Fundamentals": "mJeNghZXtMo", // Machine learning and AI
    "Ethical Hacking": "3Kq1MIfTWCE", // Ethical hacking intro
    "Docker Fundamentals": "fqMOX6JJhGo", // Docker full course
    
    // Photography
    "Digital Photography": "LxO-6rlihSg" // Photography basics
  };
  
  // Special category-based videos for fallback
  const categoryToVideo: {[key: string]: string} = {
    "Web Development": "3JluqTojuME",
    "Programming": "kqtD5dpn9C8", 
    "Data Science": "JL_grPUnXzY",
    "Design": "c9Wg6Cb_YlU",
    "Marketing": "jxjftd-Z1Co",
    "IT": "inWWhr5tnEA",
    "Technology": "JMUxmLyrhSk",
    "Photography": "LxO-6rlihSg"
  };
  
  // Get video ID by exact course title
  let videoId = titleToVideoMap[courseTitle];
  
  // If no exact match found, determine category from course title keywords
  if (!videoId) {
    // Look for category keywords in the course title
    for (const [category, video] of Object.entries(categoryToVideo)) {
      if (courseTitle.toLowerCase().includes(category.toLowerCase())) {
        videoId = video;
        console.log(`Found category match for "${courseTitle}": ${category}`);
        break;
      }
    }
  }
  
  // Default to a general programming tutorial if no match found
  if (!videoId) {
    videoId = "rfscVS0vtbw";
  }
  
  console.log(`Video for course: "${courseTitle}" -> ${videoId}`);
  return videoId;
}

interface LessonProps {
  id: number;
}

export default function Lesson({ id }: LessonProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showQuiz, setShowQuiz] = useState(false);
  const [showCertificate, setShowCertificate] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  // Fetch lesson data
  const {
    data: lessonData,
    isLoading,
    isError
  } = useQuery({
    queryKey: [`/api/lessons/${id}`],
  });
  
  // Fetch course modules and lessons
  const { data: courseModules } = useQuery({
    queryKey: [`/api/courses/${lessonData?.lesson?.courseId}/lessons`],
    enabled: !!lessonData?.lesson?.courseId,
  });
  
  // Fetch enrollment for progress tracking
  const { data: enrollments } = useQuery({
    queryKey: ["/api/enrollments"],
    enabled: !!lessonData?.lesson?.courseId,
  });
  
  const currentEnrollment = enrollments?.find(
    e => e.course.id === lessonData?.lesson?.courseId
  );
  
  const handleQuizComplete = async (score: number, total: number) => {
    setQuizCompleted(true);
    
    // Calculate pass/fail (70% threshold)
    const passPercentage = (score / total) * 100;
    const isPassed = passPercentage >= 70;
    
    toast({
      title: isPassed ? "Quiz Passed!" : "Quiz Needs Review",
      description: isPassed 
        ? `You got ${score} out of ${total} questions correct. You've completed this lesson.` 
        : `You got ${score} out of ${total}. Try reviewing the material and retaking the quiz.`,
      variant: isPassed ? "default" : "destructive",
    });
    
    // Update enrollment progress
    if (currentEnrollment) {
      try {
        // Calculate new progress
        const progressIncrement = 100 / (courseModules?.reduce((total, module) => total + module.lessons.length, 0) || 1);
        const newProgress = Math.min(100, Math.round(currentEnrollment.progress + progressIncrement));
        
        // Check if course is completed
        const isCourseCompleted = newProgress >= 100;
        
        await apiRequest("PUT", `/api/enrollments/${currentEnrollment.id}/progress`, {
          progress: newProgress,
          isCompleted: isCourseCompleted
        });
        
        // If course is completed, show certificate option
        if (isCourseCompleted) {
          setShowCertificate(true);
          toast({
            title: "Congratulations!",
            description: "You've completed the course! You can now download your certificate.",
          });
        }
        
        // Invalidate queries to refresh data
        queryClient.invalidateQueries({ queryKey: ["/api/enrollments"] });
        
      } catch (error) {
        console.error("Error updating progress:", error);
      }
    }
  };
  
  // Prepare modules data for CourseProgress component
  const formatModulesForProgress = () => {
    if (!courseModules) return [];
    
    return courseModules.map(module => ({
      id: module.id,
      title: module.title,
      lessons: module.lessons.map(lesson => ({
        id: lesson.id,
        title: lesson.title,
        duration: lesson.duration,
        isCompleted: false, // TODO: Track completed lessons
        isCurrent: lesson.id === id,
        isLocked: false // TODO: Add logic for locked lessons
      }))
    }));
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 text-primary animate-spin" />
      </div>
    );
  }
  
  if (isError || !lessonData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-neutral-900 mb-4">
            Lesson not found
          </h1>
          <p className="mb-4">The lesson you are looking for doesn't exist or you don't have access.</p>
          <Link href="/dashboard">
            <Button>Go back to Dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }
  
  const { lesson, course, quiz } = lessonData;
  
  return (
    <div className="flex min-h-screen bg-neutral-100">
      <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 ml-0 md:ml-64 min-h-screen">
        <Header toggleSidebar={toggleSidebar} />
        
        <div className="p-6">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Lesson Content */}
            <div className="lg:w-3/4">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                {/* Course header */}
                <div className="bg-primary-700 p-6">
                  <div className="mb-1">
                    <Link href="/dashboard">
                      <a className="text-primary-100 hover:text-white inline-flex items-center">
                        <ArrowLeft className="h-4 w-4 mr-1" />
                        Back to course
                      </a>
                    </Link>
                  </div>
                  <h1 className="text-2xl font-semibold text-white">
                    {course?.title}
                  </h1>
                  <div className="flex items-center mt-1">
                    <div className="flex items-center text-primary-100 mr-4">
                      <span className="mr-1">👤</span>
                      <span>Instructor: {course?.instructor}</span>
                    </div>
                    <div className="flex items-center text-primary-100">
                      <span className="mr-1">⏱️</span>
                      <span>Duration: {course?.duration}</span>
                    </div>
                  </div>
                </div>
                
                {/* Video Player */}
                <div className="bg-neutral-900 aspect-video flex items-center justify-center relative">
                  {lesson.videoUrl ? (
                    <div className="w-full h-full">
                      {!isPlaying ? (
                        /* Preview mode with play button */
                        <div 
                          className="relative w-full h-full flex items-center justify-center" 
                          style={{ 
                            backgroundColor: `#${lesson.videoUrl}`,
                            backgroundImage: `linear-gradient(135deg, #${lesson.videoUrl} 0%, #${lesson.videoUrl}99 50%, #${lesson.videoUrl}77 100%)`
                          }}
                          onClick={() => setIsPlaying(true)}
                        >
                          {/* Decorative pattern overlay */}
                          <div className="absolute inset-0 opacity-10" 
                              style={{
                                backgroundImage: 'url("data:image/svg+xml,%3Csvg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="%23ffffff" fill-opacity="1" fill-rule="evenodd"%3E%3Ccircle cx="3" cy="3" r="3"/%3E%3Ccircle cx="13" cy="13" r="3"/%3E%3C/g%3E%3C/svg%3E")',
                                backgroundSize: '20px 20px'
                              }}
                          />
                          
                          {/* Content overlay */}
                          <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
                            <div className="bg-white bg-opacity-20 rounded-full p-5 mb-6 hover:bg-opacity-30 transition-all cursor-pointer hover:scale-110 duration-300 shadow-lg">
                              <Play className="h-12 w-12 text-white" />
                            </div>
                            <h3 className="text-white text-2xl font-semibold mb-2 text-center px-4">{lesson.title}</h3>
                            <p className="text-white text-lg">Duration: {lesson.duration}</p>
                            
                            {/* Course name at the bottom */}
                            <div className="absolute bottom-4 left-4 right-4 text-center">
                              <p className="text-white text-sm bg-black bg-opacity-30 py-1 px-3 rounded-full inline-block">
                                {course?.title || "Course"}
                              </p>
                            </div>
                          </div>
                        </div>
                      ) : (
                        /* Active video player - shows an actual video */
                        <div className="relative w-full h-full">
                          {/* YouTube embedded video player with proper video based on course title */}
                          <div className="absolute inset-0 flex items-center justify-center bg-black">
                            <iframe 
                              className="w-full h-full"
                              src={`https://www.youtube.com/embed/${getVideoIdFromTitle(course?.title || "")}?autoplay=1`}
                              title={`${course?.title || ""} Tutorial`}
                              frameBorder="0"
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                              allowFullScreen
                            ></iframe>
                          </div>
                          
                          {/* Close button to exit video mode */}
                          <button 
                            className="absolute top-3 right-3 z-20 bg-black bg-opacity-60 rounded-full p-2 text-white hover:bg-opacity-80 transition-all"
                            onClick={() => setIsPlaying(false)}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                              <line x1="18" y1="6" x2="6" y2="18"></line>
                              <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    /* Fallback if no video URL */
                    <div className="text-center">
                      <div className="bg-primary-700 rounded-full p-4 mb-4 inline-block">
                        <Play className="h-10 w-10 text-white" />
                      </div>
                      <p className="text-white text-lg">{lesson.title}</p>
                    </div>
                  )}
                </div>
                
                {/* Lesson content */}
                <div className="p-6">
                  <div className="mb-6">
                    <h2 className="text-xl font-semibold mb-4">{lesson.title}</h2>
                    <div className="prose max-w-none">
                      {lesson.content || (
                        <p className="text-neutral-700">
                          Content for this lesson is not available.
                        </p>
                      )}
                    </div>
                  </div>
                  
                  {/* Lesson resources */}
                  <div className="mb-6">
                    <h3 className="text-lg font-medium mb-3">Lesson Resources</h3>
                    <div className="flex flex-col space-y-2">
                      <a href="#" className="flex items-center p-3 border border-neutral-200 rounded-md hover:bg-neutral-50 transition-colors">
                        <span className="mr-3">📄</span>
                        <div>
                          <p className="font-medium">Lesson Slides</p>
                          <p className="text-sm text-neutral-500">PDF, 2.4 MB</p>
                        </div>
                      </a>
                      <a href="#" className="flex items-center p-3 border border-neutral-200 rounded-md hover:bg-neutral-50 transition-colors">
                        <span className="mr-3">💻</span>
                        <div>
                          <p className="font-medium">Example Code</p>
                          <p className="text-sm text-neutral-500">ZIP, 156 KB</p>
                        </div>
                      </a>
                    </div>
                  </div>
                  
                  {/* Lesson navigation */}
                  <div className="border-t pt-4 flex justify-between">
                    <Button variant="outline">
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Previous Lesson
                    </Button>
                    {quiz ? (
                      <Button onClick={() => setShowQuiz(true)}>
                        Take Quiz
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    ) : (
                      <Button>
                        Next Lesson
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
              
              {/* Quiz Section */}
              {quiz && showQuiz && !quizCompleted && (
                <div className="mt-6">
                  <Quiz
                    quizId={quiz.id}
                    title={quiz.title}
                    courseId={course?.id}
                    lessonId={lesson.id}
                    questions={quiz.questions.map(q => ({
                      id: q.id,
                      question: q.question,
                      options: JSON.parse(q.options),
                      correctAnswer: q.correctAnswer
                    }))}
                    onComplete={handleQuizComplete}
                  />
                </div>
              )}
              
              {/* Certificate Section */}
              {showCertificate && (
                <div className="mt-6 bg-white rounded-lg shadow-md p-6">
                  <div className="flex items-center mb-4">
                    <Award className="h-8 w-8 text-yellow-500 mr-3" />
                    <h2 className="text-xl font-semibold">Course Completed!</h2>
                  </div>
                  
                  <p className="mb-6 text-gray-700">
                    Congratulations! You have successfully completed <strong>{course?.title}</strong>. 
                    Generate and download your certificate to showcase your achievement.
                  </p>
                  
                  <Certificate 
                    courseTitle={course?.title || ""} 
                    completionDate={new Date()} 
                    courseId={course?.id || 0} 
                  />
                </div>
              )}
            </div>
            
            {/* Course Sidebar */}
            <div className="lg:w-1/4">
              <CourseProgress
                progress={currentEnrollment?.progress || 0}
                modules={formatModulesForProgress()}
                currentLessonId={id}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
