import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  // Add auth from our logged in user
  const storedUser = localStorage.getItem("lms_user");
  
  const headers: Record<string, string> = {
    "Content-Type": "application/json"
  };
  
  if (storedUser) {
    // Create a simple token for our API auth - in a real app this would be a JWT
    headers["Authorization"] = `Bearer lms-simple-auth`;
  }
  
  try {
    console.log("API Request:", method, url, data);
    
    const res = await fetch(url, {
      method,
      headers,
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
    });
    
    if (!res.ok) {
      console.error("API Error:", {
        status: res.status,
        statusText: res.statusText,
        url,
        method
      });
      
      // Don't throw for these errors, just return the response
      // so that the caller can handle them
      return res;
    }
    
    return res;
  } catch (error) {
    console.error("Fetch error:", error);
    throw error;
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    // Add auth headers for API requests
    const storedUser = localStorage.getItem("lms_user");
    const headers: Record<string, string> = {};
    
    if (storedUser) {
      headers["Authorization"] = `Bearer lms-simple-auth`;
    }
    
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
      headers
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
