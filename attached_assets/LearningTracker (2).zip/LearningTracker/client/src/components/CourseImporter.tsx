import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Download, Loader2 } from "lucide-react";

export default function CourseImporter() {
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState<{
    success: boolean;
    message: string;
    count: number;
  } | null>(null);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Import courses from API
  const importCoursesMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/courses/fetch-api", {});
    },
    onSuccess: (data: any) => {
      setImportResult({
        success: true,
        message: "Courses imported successfully!",
        count: data.courses?.length || 0
      });
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      toast({
        title: "Import Successful",
        description: `Successfully imported ${data.courses?.length || 0} courses from the API.`,
      });
    },
    onError: (error) => {
      setImportResult({
        success: false,
        message: "Failed to import courses. Please try again.",
        count: 0
      });
      toast({
        title: "Import Failed",
        description: "There was an error importing courses from the API.",
        variant: "destructive",
      });
      console.error("Import error:", error);
    },
    onSettled: () => {
      setIsImporting(false);
    }
  });

  // Handle course import
  const handleImportCourses = async () => {
    setIsImporting(true);
    setImportResult(null);
    importCoursesMutation.mutate();
  };
  
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium">Import Courses</h3>
        <Button 
          onClick={handleImportCourses}
          disabled={isImporting}
          className="flex items-center"
        >
          {isImporting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Importing...
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Import Courses from API
            </>
          )}
        </Button>
      </div>
      <p className="text-neutral-600 mb-2">
        Fetch and import courses from external educational APIs to populate your platform.
      </p>
      {importResult && (
        <div className={`mt-4 p-3 rounded-md ${
          importResult.success 
            ? "bg-green-50 text-green-700 border border-green-200" 
            : "bg-red-50 text-red-700 border border-red-200"
        }`}>
          <p className="font-medium">{importResult.message}</p>
          {importResult.count > 0 && (
            <p className="text-sm mt-1">Successfully imported {importResult.count} courses.</p>
          )}
        </div>
      )}
    </div>
  );
}