import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, PlayCircle, Lock } from "lucide-react";
import { Link } from "wouter";

interface LessonItem {
  id: number;
  title: string;
  duration: string;
  isCompleted?: boolean;
  isCurrent?: boolean;
  isLocked?: boolean;
}

interface ModuleItem {
  id: number;
  title: string;
  lessons: LessonItem[];
}

interface CourseProgressProps {
  progress: number;
  modules: ModuleItem[];
  currentLessonId?: number;
}

export default function CourseProgress({
  progress,
  modules,
  currentLessonId
}: CourseProgressProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h3 className="font-semibold text-lg mb-4">Course Progress</h3>
      <div className="mb-3">
        <div className="flex justify-between text-sm mb-1">
          <span className="text-neutral-600">Overall Progress</span>
          <span className="text-primary-500 font-medium">{progress}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>
      
      <h3 className="font-semibold mb-3 mt-4">Course Content</h3>
      <div className="border rounded-md">
        <Accordion type="multiple" defaultValue={["module-1"]}>
          {modules.map((module, index) => (
            <AccordionItem key={module.id} value={`module-${index + 1}`}>
              <AccordionTrigger className="px-3 py-3 hover:bg-neutral-50">
                <h4 className="font-medium text-left">{index + 1}. {module.title}</h4>
              </AccordionTrigger>
              <AccordionContent className="px-3 pb-3">
                <ul className="space-y-2 text-sm">
                  {module.lessons.map((lesson) => (
                    <li 
                      key={lesson.id} 
                      className={`flex items-center ${
                        lesson.isCompleted 
                          ? "text-green-500" 
                          : lesson.isCurrent 
                            ? "text-primary-500 font-medium" 
                            : "text-neutral-700"
                      }`}
                    >
                      {lesson.isCompleted ? (
                        <CheckCircle className="h-4 w-4 mr-2" />
                      ) : lesson.isLocked ? (
                        <Lock className="h-4 w-4 mr-2 text-neutral-400" />
                      ) : (
                        <PlayCircle className="h-4 w-4 mr-2" />
                      )}
                      
                      {lesson.isLocked ? (
                        <span>{lesson.title}</span>
                      ) : (
                        <Link href={`/lessons/${lesson.id}`}>
                          <a className={lesson.isCurrent ? "font-medium" : ""}>
                            {lesson.title}
                          </a>
                        </Link>
                      )}
                      
                      <span className="ml-auto text-neutral-500">{lesson.duration}</span>
                    </li>
                  ))}
                </ul>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  );
}
