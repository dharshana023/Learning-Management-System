import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  BookOpen,
  GraduationCap,
  Award,
  MessageCircle,
  Bell,
  Settings,
  LogOut,
  ShieldCheck,
  Menu
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

export default function Sidebar({ isOpen, toggleSidebar }: SidebarProps) {
  const [location] = useLocation();
  const { user, logout, isAdmin } = useAuth();
  
  const firstName = user?.firstName || "";
  const lastName = user?.lastName || "";
  const initials = `${firstName.charAt(0)}${lastName.charAt(0)}`;

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <>
      {/* Mobile sidebar backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={toggleSidebar}
        ></div>
      )}
      
      {/* Sidebar */}
      <aside 
        className={cn(
          "w-64 bg-white shadow-md flex-shrink-0 h-screen fixed left-0 overflow-y-auto z-30 transition-transform duration-300 ease-in-out",
          isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >
        <div className="p-4 border-b">
          <h1 className="text-2xl font-semibold text-primary">EduLearn</h1>
        </div>
        
        <div className="py-4">
          <div className="px-4 mb-4">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 font-semibold">
                {initials}
              </div>
              <div>
                <h3 className="font-medium text-neutral-900">
                  {firstName} {lastName}
                </h3>
                <p className="text-sm text-neutral-500">{user?.role === "admin" ? "Admin" : "Student"}</p>
              </div>
            </div>
          </div>
          
          <ul className="space-y-1">
            <li>
              <Link href="/dashboard">
                <a className={cn(
                  "flex items-center px-4 py-3 text-neutral-700 hover:bg-neutral-100 transition-colors",
                  isActive("/dashboard") && "bg-primary-50 text-primary-600 border-l-2 border-primary"
                )}>
                  <LayoutDashboard className="h-5 w-5 mr-3 text-neutral-500" />
                  Dashboard
                </a>
              </Link>
            </li>
            <li>
              <Link href="/courses">
                <a className={cn(
                  "flex items-center px-4 py-3 text-neutral-700 hover:bg-neutral-100 transition-colors",
                  isActive("/courses") && "bg-primary-50 text-primary-600 border-l-2 border-primary"
                )}>
                  <BookOpen className="h-5 w-5 mr-3 text-neutral-500" />
                  Courses
                </a>
              </Link>
            </li>
            <li>
              <Link href="/dashboard">
                <a className={cn(
                  "flex items-center px-4 py-3 text-neutral-700 hover:bg-neutral-100 transition-colors"
                )}>
                  <GraduationCap className="h-5 w-5 mr-3 text-neutral-500" />
                  My Learning
                </a>
              </Link>
            </li>
            <li>
              <Link href="/dashboard">
                <a className={cn(
                  "flex items-center px-4 py-3 text-neutral-700 hover:bg-neutral-100 transition-colors"
                )}>
                  <Award className="h-5 w-5 mr-3 text-neutral-500" />
                  Certificates
                </a>
              </Link>
            </li>
            <li>
              <Link href="/dashboard">
                <a className={cn(
                  "flex items-center px-4 py-3 text-neutral-700 hover:bg-neutral-100 transition-colors"
                )}>
                  <MessageCircle className="h-5 w-5 mr-3 text-neutral-500" />
                  Discussions
                </a>
              </Link>
            </li>
            <li>
              <Link href="/dashboard">
                <a className={cn(
                  "flex items-center px-4 py-3 text-neutral-700 hover:bg-neutral-100 transition-colors"
                )}>
                  <Bell className="h-5 w-5 mr-3 text-neutral-500" />
                  Notifications
                  <span className="ml-auto bg-primary text-white text-xs px-2 py-1 rounded-full">3</span>
                </a>
              </Link>
            </li>
            
            <li className="border-t my-4"></li>
            
            {isAdmin && (
              <li>
                <Link href="/admin">
                  <a className={cn(
                    "flex items-center px-4 py-3 text-neutral-700 hover:bg-neutral-100 transition-colors",
                    isActive("/admin") && "bg-primary-50 text-primary-600 border-l-2 border-primary"
                  )}>
                    <ShieldCheck className="h-5 w-5 mr-3 text-neutral-500" />
                    Admin Panel
                  </a>
                </Link>
              </li>
            )}
            <li>
              <Link href="/settings">
                <a className={cn(
                  "flex items-center px-4 py-3 text-neutral-700 hover:bg-neutral-100 transition-colors",
                  isActive("/settings") && "bg-primary-50 text-primary-600 border-l-2 border-primary"
                )}>
                  <Settings className="h-5 w-5 mr-3 text-neutral-500" />
                  Settings
                </a>
              </Link>
            </li>
            <li>
              <Button
                variant="ghost" 
                onClick={logout}
                className="w-full justify-start px-4 py-3 text-neutral-700 hover:bg-neutral-100 rounded-none font-normal"
              >
                <LogOut className="h-5 w-5 mr-3 text-neutral-500" />
                Logout
              </Button>
            </li>
          </ul>
        </div>
      </aside>
    </>
  );
}
