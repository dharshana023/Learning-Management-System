import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { 
  Search,
  Menu,
  Bell,
  HelpCircle
} from "lucide-react";
import { Input } from "@/components/ui/input";

interface HeaderProps {
  toggleSidebar: () => void;
  onSearch?: (query: string) => void;
}

export default function Header({ toggleSidebar, onSearch }: HeaderProps) {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  
  const firstName = user?.firstName || "";
  const lastName = user?.lastName || "";
  const initials = `${firstName.charAt(0)}${lastName.charAt(0)}`;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(searchQuery);
    }
  };

  return (
    <header className="bg-white shadow-sm px-6 py-3 flex items-center justify-between sticky top-0 z-20">
      <div className="flex items-center md:hidden">
        <button 
          onClick={toggleSidebar}
          className="text-neutral-500 focus:outline-none"
        >
          <Menu className="h-6 w-6" />
        </button>
      </div>
      
      <form 
        onSubmit={handleSearch}
        className="flex items-center w-full max-w-lg"
      >
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-4 w-4" />
          <Input
            type="text"
            className="w-full pl-10 pr-4 py-2"
            placeholder="Search courses, lessons..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </form>
      
      <div className="flex items-center space-x-4">
        <button className="text-neutral-500 focus:outline-none">
          <HelpCircle className="h-5 w-5" />
        </button>
        <button className="relative text-neutral-500 focus:outline-none">
          <Bell className="h-5 w-5" />
          <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-primary ring-2 ring-white"></span>
        </button>
        <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 font-semibold text-sm">
          {initials}
        </div>
      </div>
    </header>
  );
}
