import { useState } from "react";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer?: string;
}

interface QuizProps {
  quizId: number;
  title: string;
  questions: QuizQuestion[];
  lessonId?: number;
  courseId?: number;
  onComplete?: (score: number, total: number) => void;
}

export default function Quiz({ quizId, title, questions, lessonId, courseId, onComplete }: QuizProps) {
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  const handleAnswerChange = (questionId: number, answer: string) => {
    if (!submitted) {
      setAnswers(prev => ({
        ...prev,
        [questionId]: answer
      }));
    }
  };
  
  const handleSubmit = async () => {
    // Check if all questions are answered
    if (Object.keys(answers).length < questions.length) {
      toast({
        title: "Incomplete Quiz",
        description: "Please answer all questions before submitting.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Calculate score
      let correctCount = 0;
      
      questions.forEach(question => {
        if (answers[question.id] === question.correctAnswer) {
          correctCount++;
        }
      });
      
      const scorePercent = Math.round((correctCount / questions.length) * 100);
      setScore(scorePercent);
      
      // Submit to API with additional data
      await apiRequest("POST", `/api/quizzes/${quizId}/attempts`, {
        score: scorePercent,
        lessonId,
        courseId,
        answers
      });
      
      setSubmitted(true);
      
      // Call onComplete callback if provided
      if (onComplete) {
        onComplete(correctCount, questions.length);
      }
      
      toast({
        title: "Quiz Submitted",
        description: `You scored ${correctCount} out of ${questions.length} (${scorePercent}%)`,
      });
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "There was an error submitting your quiz. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleContinue = () => {
    if (onComplete) {
      onComplete(score, questions.length);
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Quiz: {title}</h2>
      <p className="text-neutral-700 mb-6">
        Test your understanding of concepts covered in this lesson.
      </p>
      
      <div className="space-y-8">
        {questions.map((question, index) => (
          <div key={question.id} className="mb-6">
            <p className="font-medium mb-3">
              {index + 1}. {question.question}
            </p>
            <RadioGroup
              value={answers[question.id]}
              onValueChange={(value) => handleAnswerChange(question.id, value)}
              disabled={submitted}
            >
              <div className="space-y-2">
                {question.options.map((option, optIndex) => (
                  <div key={optIndex} className="flex items-start">
                    <RadioGroupItem
                      value={option}
                      id={`q${question.id}-opt${optIndex}`}
                      className="mt-1"
                    />
                    <div className="ml-2 space-y-1">
                      <Label
                        htmlFor={`q${question.id}-opt${optIndex}`}
                        className={`${
                          submitted && option === question.correctAnswer
                            ? "text-green-600 font-medium"
                            : submitted && answers[question.id] === option && option !== question.correctAnswer
                              ? "text-red-600"
                              : ""
                        }`}
                      >
                        {option}
                        {submitted && option === question.correctAnswer && (
                          <CheckCircle className="inline-block ml-2 h-4 w-4 text-green-600" />
                        )}
                        {submitted && answers[question.id] === option && option !== question.correctAnswer && (
                          <AlertCircle className="inline-block ml-2 h-4 w-4 text-red-600" />
                        )}
                      </Label>
                    </div>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </div>
        ))}
      </div>
      
      {!submitted ? (
        <Button
          onClick={handleSubmit}
          className="w-full"
          disabled={Object.keys(answers).length < questions.length || isSubmitting}
        >
          {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Submit Quiz
        </Button>
      ) : (
        <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-md">
          <div className="flex items-start">
            <CheckCircle className="text-green-500 mr-2 h-5 w-5" />
            <div>
              <h3 className="font-medium text-green-500">Quiz Completed!</h3>
              <p className="text-neutral-700 mt-1">
                Your score: <span className="font-semibold">{score}%</span>
              </p>
              <p className="text-neutral-600 text-sm mt-2">
                {score >= 70
                  ? "Great job! You've successfully completed this lesson's quiz."
                  : "Keep learning! Review the material and try again."}
              </p>
              <div className="mt-4">
                <Button onClick={handleContinue}>
                  Continue to Next Lesson
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
