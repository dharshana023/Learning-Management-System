import { Link } from "wouter";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Star, StarHalf } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

interface Course {
  id: number;
  title: string;
  description: string;
  category: string;
  level: string;
  imageUrl: string;
  instructor: string;
  duration: string;
  lessonsCount: number;
  price: string;
  rating: string;
  reviewCount: number;
}

interface CourseCardProps {
  course: Course;
  progress?: number;
  isEnrolled?: boolean;
  isCompleted?: boolean;
  variant?: "dashboard" | "catalog" | "recommended";
}

export default function CourseCard({
  course,
  progress,
  isEnrolled = false,
  isCompleted = false,
  variant = "dashboard"
}: CourseCardProps) {
  const [isEnrolling, setIsEnrolling] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Function to render star rating
  const renderRating = (rating: string) => {
    const ratingNum = parseFloat(rating);
    const fullStars = Math.floor(ratingNum);
    const hasHalfStar = ratingNum % 1 >= 0.5;
    
    return (
      <span className="text-yellow-500 flex">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={`star-${i}`} className="h-4 w-4 fill-current" />
        ))}
        {hasHalfStar && <StarHalf className="h-4 w-4 fill-current" />}
      </span>
    );
  };
  
  const handleEnroll = async () => {
    try {
      setIsEnrolling(true);
      await apiRequest("POST", "/api/enrollments", { courseId: course.id });
      
      toast({
        title: "Enrollment Successful",
        description: `You have successfully enrolled in "${course.title}"`,
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments"] });
      
    } catch (error) {
      toast({
        title: "Enrollment Failed",
        description: "There was an error enrolling in this course. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsEnrolling(false);
    }
  };

  if (variant === "dashboard") {
    return (
      <div className="bg-white rounded-lg shadow overflow-hidden transition-all duration-200 hover:shadow-md hover:-translate-y-1">
        <img 
          src={course.imageUrl} 
          alt={course.title} 
          className="w-full h-40 object-cover"
        />
        
        <div className="p-5">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-semibold text-lg">{course.title}</h3>
            <span className={`${
              isCompleted 
                ? "bg-green-100 text-green-600" 
                : "bg-primary-100 text-primary-600"
            } text-xs px-2 py-1 rounded-full`}>
              {isCompleted ? "Completed" : "In Progress"}
            </span>
          </div>
          <p className="text-neutral-600 text-sm mb-4">{course.description}</p>
          
          <div className="mb-3">
            <div className="flex justify-between text-sm mb-1">
              <span className="text-neutral-600">Progress</span>
              <span className={`${
                isCompleted ? "text-green-500" : "text-primary-500"
              } font-medium`}>
                {progress}%
              </span>
            </div>
            <Progress 
              value={progress} 
              className="h-2" 
              indicatorClassName={isCompleted ? "bg-green-500" : ""}
            />
          </div>
          
          <Link href={`/lessons/${course.id}`}>
            <Button className="w-full">
              {isCompleted ? "Review Course" : "Continue"}
            </Button>
          </Link>
        </div>
      </div>
    );
  }
  
  if (variant === "catalog") {
    return (
      <div className="bg-white rounded-lg shadow overflow-hidden transition-all duration-200 hover:shadow-md hover:-translate-y-1">
        <img 
          src={course.imageUrl} 
          alt={course.title} 
          className="w-full h-48 object-cover"
        />
        
        <div className="p-5">
          <div className="mb-2">
            <span className={`
              inline-block text-xs px-2 py-1 rounded-full mr-2
              ${course.category === "Web Development" ? "bg-blue-100 text-blue-800" : ""}
              ${course.category === "Data Science" ? "bg-purple-100 text-purple-800" : ""}
              ${course.category === "Design" ? "bg-pink-100 text-pink-800" : ""}
            `}>
              {course.category}
            </span>
            <span className={`
              inline-block text-xs px-2 py-1 rounded-full
              ${course.level === "Beginner" ? "bg-green-100 text-green-800" : ""}
              ${course.level === "Intermediate" ? "bg-yellow-100 text-yellow-800" : ""}
              ${course.level === "Advanced" ? "bg-red-100 text-red-800" : ""}
            `}>
              {course.level}
            </span>
          </div>
          
          <h3 className="font-semibold text-lg mb-2">{course.title}</h3>
          <p className="text-neutral-600 text-sm mb-3">{course.description}</p>
          
          <div className="flex items-center text-sm mb-4">
            {renderRating(course.rating)}
            <span className="ml-1 text-neutral-500">{course.rating} ({course.reviewCount} reviews)</span>
          </div>
          
          <div className="flex items-center text-sm text-neutral-600 mb-4">
            <span className="mr-1">⏱️</span>
            {course.duration}
            <span className="mx-2">•</span>
            <span className="mr-1">🎬</span>
            {course.lessonsCount} lessons
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-primary-500 font-semibold text-lg">{course.price}</span>
            <Button 
              onClick={handleEnroll} 
              disabled={isEnrolled || isEnrolling}
            >
              {isEnrolled ? "Enrolled" : "Enroll Now"}
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  // Recommended variant (smaller card)
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden transition-all duration-200 hover:shadow-md hover:-translate-y-1">
      <img 
        src={course.imageUrl} 
        alt={course.title} 
        className="w-full h-32 object-cover"
      />
      
      <div className="p-4">
        <h3 className="font-semibold">{course.title}</h3>
        <div className="flex items-center text-sm mt-1 mb-2">
          {renderRating(course.rating)}
          <span className="ml-1 text-neutral-500">({course.reviewCount})</span>
        </div>
        <p className="text-neutral-600 text-xs">Instructor: {course.instructor}</p>
        <div className="flex justify-between items-center mt-3">
          <span className="text-primary-500 font-semibold">{course.price}</span>
          <Button 
            variant="outline" 
            size="sm" 
            className="text-primary-600 bg-primary-50 hover:bg-primary-100 border-none"
          >
            + Add to Wishlist
          </Button>
        </div>
      </div>
    </div>
  );
}
