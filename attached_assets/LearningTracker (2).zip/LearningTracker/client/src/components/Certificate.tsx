import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";

interface CertificateProps {
  courseTitle: string;
  completionDate: Date;
  courseId: number;
}

export default function Certificate({ courseTitle, completionDate, courseId }: CertificateProps) {
  const certificateRef = useRef<HTMLDivElement>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };
  
  const handleDownload = async () => {
    if (!certificateRef.current) return;
    
    setIsGenerating(true);
    
    try {
      // First capture the certificate as canvas
      const canvas = await html2canvas(certificateRef.current, {
        scale: 2, // Higher scale for better quality
        logging: false,
        useCORS: true,
        backgroundColor: "#ffffff"
      });
      
      // Create PDF with proper dimensions
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'mm',
        format: 'a4'
      });
      
      const imgWidth = 297; // A4 width in mm (landscape)
      const imgHeight = canvas.height * imgWidth / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.save(`${courseTitle.replace(/\s+/g, '_')}_Certificate.pdf`);
      
      toast({
        title: "Certificate Downloaded",
        description: "Your certificate has been downloaded successfully.",
      });
    } catch (error) {
      console.error("Error generating certificate:", error);
      toast({
        title: "Download Failed",
        description: "There was an error generating your certificate. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  return (
    <div className="flex flex-col items-center space-y-6">
      {/* Certificate preview */}
      <div ref={certificateRef} className="w-full max-w-4xl bg-white border-8 border-blue-100 p-8 shadow-lg">
        <div className="flex items-center justify-center mb-6">
          <div className="w-24 h-24 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center">
            <span className="text-white text-3xl font-bold">Edu</span>
          </div>
        </div>
        
        <div className="text-center">
          <h1 className="text-3xl font-serif text-blue-800 mb-2">Certificate of Completion</h1>
          <div className="w-32 h-1 bg-blue-500 mx-auto mb-6"></div>
          
          <p className="text-lg text-neutral-600 mb-8">This is to certify that</p>
          
          <h2 className="text-2xl font-bold text-blue-900 mb-1">
            {user?.firstName} {user?.lastName}
          </h2>
          <p className="text-neutral-600 italic mb-8">has successfully completed</p>
          
          <h3 className="text-2xl font-bold text-blue-800 mb-6 border-b border-blue-200 pb-2 mx-auto w-max">
            {courseTitle}
          </h3>
          
          <p className="text-neutral-600 mb-8">
            on <span className="font-semibold">{formatDate(completionDate)}</span>
          </p>
          
          <div className="flex justify-center space-x-16 mt-8">
            <div className="text-center">
              <div className="border-t border-neutral-400 pt-2 w-40">
                <p className="font-semibold text-neutral-800">David Wilson</p>
                <p className="text-sm text-neutral-600">Instructor</p>
              </div>
            </div>
            
            <div className="text-center">
              <div className="border-t border-neutral-400 pt-2 w-40">
                <p className="font-semibold text-neutral-800">EduLearn</p>
                <p className="text-sm text-neutral-600">Certificate ID: {courseId}-{user?.id}-{completionDate.getTime()}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <Button 
        onClick={handleDownload} 
        disabled={isGenerating} 
        size="lg"
        className="bg-blue-600 hover:bg-blue-700"
      >
        {isGenerating ? "Generating PDF..." : "Download Certificate"}
      </Button>
    </div>
  );
}