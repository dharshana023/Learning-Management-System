import { Router, Request, Response } from "express";
import { fetchCoursesFromAPI, storeCoursesInDB, getCoursesFromDB } from "../services/courseService";
import { storage } from "../storage";

const router = Router();

// Get all courses (from database if available, otherwise from storage)
router.get("/", async (req, res) => {
  try {
    // Try to get courses from database first
    const dbCourses = await getCoursesFromDB();
    
    if (dbCourses && dbCourses.length > 0) {
      // If courses exist in database, return them
      console.log(`Returning ${dbCourses.length} courses from database`);
      return res.json(dbCourses);
    } else {
      // Fall back to in-memory storage if database has no courses
      const { category, level, search } = req.query;
      let courses = await storage.getAllCourses();
      
      // Apply filters if provided
      if (category) {
        courses = courses.filter(course => 
          course.category.toLowerCase() === (category as string).toLowerCase()
        );
      }
      
      if (level) {
        courses = courses.filter(course => 
          course.level.toLowerCase() === (level as string).toLowerCase()
        );
      }
      
      if (search) {
        const searchTerm = (search as string).toLowerCase();
        courses = courses.filter(course => 
          course.title.toLowerCase().includes(searchTerm) || 
          course.description.toLowerCase().includes(searchTerm)
        );
      }
      
      return res.json(courses);
    }
  } catch (error) {
    console.error("Error fetching courses:", error);
    res.status(500).json({ message: "Error fetching courses" });
  }
});

// Fetch courses from external API and store in database
router.post("/fetch-api", async (req, res) => {
  try {
    // Fetch courses from API
    const apiCourses = await fetchCoursesFromAPI();
    
    if (!apiCourses || apiCourses.length === 0) {
      return res.status(404).json({ message: "No courses found from API" });
    }
    
    // Store courses in database
    const storedCourses = await storeCoursesInDB(apiCourses);
    
    res.status(201).json({ 
      message: `Successfully fetched and stored ${storedCourses.length} courses`, 
      courses: storedCourses 
    });
  } catch (error) {
    console.error("Error fetching courses from API:", error);
    res.status(500).json({ 
      message: "Error fetching courses from API", 
      error: error instanceof Error ? error.message : "Unknown error" 
    });
  }
});

// Get a single course by ID
router.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid course ID" });
    }
    
    // Try to get course from database first
    const dbCourses = await getCoursesFromDB();
    const dbCourse = dbCourses.find(course => course.id === id);
    
    if (dbCourse) {
      return res.json(dbCourse);
    }
    
    // Fall back to in-memory storage
    const course = await storage.getCourse(id);
    
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }
    
    res.json(course);
  } catch (error) {
    console.error("Error fetching course:", error);
    res.status(500).json({ message: "Error fetching course" });
  }
});

export default router;