import { 
  User, InsertUser, users, 
  Course, InsertCourse, courses,
  Enrollment, InsertEnrollment, enrollments,
  Lesson, InsertLesson, lessons,
  Module, InsertModule, modules,
  Quiz, InsertQuiz, quizzes,
  QuizQuestion, InsertQuizQuestion, quizQuestions,
  QuizAttempt, InsertQuizAttempt, quizAttempts
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Course operations
  getCourse(id: number): Promise<Course | undefined>;
  getAllCourses(): Promise<Course[]>;
  getCoursesByCategory(category: string): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: Partial<InsertCourse>): Promise<Course | undefined>;
  deleteCourse(id: number): Promise<boolean>;
  
  // Enrollment operations
  getEnrollment(userId: number, courseId: number): Promise<Enrollment | undefined>;
  getEnrollmentsByUser(userId: number): Promise<Enrollment[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  updateEnrollmentProgress(id: number, progress: number): Promise<Enrollment | undefined>;
  completeEnrollment(id: number): Promise<Enrollment | undefined>;
  
  // Lesson operations
  getLesson(id: number): Promise<Lesson | undefined>;
  getLessonsByCourse(courseId: number): Promise<Lesson[]>;
  getLessonsByModule(moduleId: number): Promise<Lesson[]>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  
  // Module operations
  getModule(id: number): Promise<Module | undefined>;
  getModulesByCourse(courseId: number): Promise<Module[]>;
  createModule(module: InsertModule): Promise<Module>;
  
  // Quiz operations
  getQuiz(id: number): Promise<Quiz | undefined>;
  getQuizByLesson(lessonId: number): Promise<Quiz | undefined>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  
  // Quiz question operations
  getQuizQuestions(quizId: number): Promise<QuizQuestion[]>;
  createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion>;
  
  // Quiz attempt operations
  getQuizAttempts(userId: number, quizId: number): Promise<QuizAttempt[]>;
  createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  // Storage maps
  public users: Map<number, User>;
  private courses: Map<number, Course>;
  private enrollments: Map<number, Enrollment>;
  private lessons: Map<number, Lesson>;
  private modules: Map<number, Module>;
  private quizzes: Map<number, Quiz>;
  private quizQuestions: Map<number, QuizQuestion>;
  private quizAttempts: Map<number, QuizAttempt>;
  
  // Auto-increment IDs
  private userId: number;
  private courseId: number;
  private enrollmentId: number;
  private lessonId: number;
  private moduleId: number;
  private quizId: number;
  private questionId: number;
  private attemptId: number;
  
  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.enrollments = new Map();
    this.lessons = new Map();
    this.modules = new Map();
    this.quizzes = new Map();
    this.quizQuestions = new Map();
    this.quizAttempts = new Map();
    
    this.userId = 1;
    this.courseId = 1;
    this.enrollmentId = 1;
    this.lessonId = 1;
    this.moduleId = 1;
    this.quizId = 1;
    this.questionId = 1;
    this.attemptId = 1;
    
    // Initialize with sample data for development
    this.initSampleData();
  }

  // Initialize sample data
  private initSampleData() {
    // Create admin user directly without using createUser method
    const adminId = this.userId++;
    const adminUser: User = {
      id: adminId,
      username: "admin@edulearn.com",
      password: "password",
      firstName: "Admin",
      lastName: "User",
      role: "admin"
    };
    this.users.set(adminId, adminUser);
    
    // Create student user directly without using createUser method
    const studentId = this.userId++;
    const studentUser: User = {
      id: studentId,
      username: "john@example.com",
      password: "password",
      firstName: "John",
      lastName: "Smith",
      role: "student"
    };
    this.users.set(studentId, studentUser);
    
    // Sample courses
    const webDevCourse: InsertCourse = {
      title: "Web Development Fundamentals",
      description: "Learn the core technologies of web development: HTML, CSS, and JavaScript.",
      category: "Web Development",
      level: "Beginner",
      imageUrl: "https://images.unsplash.com/photo-1593720213428-28a5b9e94613",
      instructor: "David Wilson",
      duration: "8 weeks",
      lessonsCount: 24,
      price: "$49.99",
      rating: "4.7",
      reviewCount: 215,
      status: "published"
    };
    
    const dataScienceCourse: InsertCourse = {
      title: "Data Science Essentials",
      description: "Introduction to data analysis, visualization, and machine learning basics.",
      category: "Data Science",
      level: "Intermediate",
      imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71",
      instructor: "Sarah Johnson",
      duration: "10 weeks",
      lessonsCount: 30,
      price: "$59.99",
      rating: "4.8",
      reviewCount: 187,
      status: "published"
    };
    
    const uxDesignCourse: InsertCourse = {
      title: "UX Design Principles",
      description: "Master the fundamentals of user experience design and usability principles.",
      category: "Design",
      level: "Beginner",
      imageUrl: "https://images.unsplash.com/photo-1561070791-2526d30994b5",
      instructor: "Michelle Lee",
      duration: "6 weeks",
      lessonsCount: 18,
      price: "$45.99",
      rating: "4.6",
      reviewCount: 142,
      status: "published"
    };
    
    const pythonBasicsCourse: InsertCourse = {
      title: "Python Programming Basics",
      description: "Learn Python programming from scratch with practical examples and projects.",
      category: "Programming",
      level: "Beginner",
      imageUrl: "https://images.unsplash.com/photo-1526379879527-8559ecfcaec0",
      instructor: "Michael Brown",
      duration: "6 weeks",
      lessonsCount: 20,
      price: "Free",
      rating: "4.9",
      reviewCount: 230,
      status: "published"
    };
    
    const digitalMarketingCourse: InsertCourse = {
      title: "Digital Marketing Fundamentals",
      description: "Learn the essentials of digital marketing strategies and tools.",
      category: "Marketing",
      level: "Beginner",
      imageUrl: "https://images.unsplash.com/photo-1557838923-2985c318be48",
      instructor: "Jennifer Adams",
      duration: "5 weeks",
      lessonsCount: 15,
      price: "Free",
      rating: "4.5",
      reviewCount: 120,
      status: "published"
    };
    
    const introToAICourse: InsertCourse = {
      title: "Introduction to Artificial Intelligence",
      description: "Understand the fundamentals of AI, machine learning, and neural networks.",
      category: "Technology",
      level: "Intermediate",
      imageUrl: "https://images.unsplash.com/photo-1677442135188-6cab7f96ab05",
      instructor: "Dr. Robert Williams",
      duration: "8 weeks",
      lessonsCount: 24,
      price: "Free",
      rating: "4.9",
      reviewCount: 175,
      status: "published"
    };
    
    // Create 19 more free courses
    const freeCourses = [
      {
        title: "Mobile App Development",
        description: "Build cross-platform mobile applications.",
        category: "Development",
        level: "Intermediate",
        imageUrl: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c",
        instructor: "Sarah Johnson",
        duration: "6 weeks",
        lessonsCount: 18,
        price: "Free",
        rating: "4.7",
        reviewCount: 128,
        status: "published"
      },
      {
        title: "Cloud Computing",
        description: "Understand cloud infrastructure basics.",
        category: "IT & Software",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8",
        instructor: "Michael Thompson",
        duration: "4 weeks",
        lessonsCount: 12,
        price: "Free",
        rating: "4.6",
        reviewCount: 105,
        status: "published"
      },
      {
        title: "Introduction to Blockchain",
        description: "Learn blockchain technology basics.",
        category: "Technology",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1639762681057-408e52192e55",
        instructor: "Daniel Lee",
        duration: "5 weeks",
        lessonsCount: 15,
        price: "Free",
        rating: "4.8",
        reviewCount: 156,
        status: "published"
      },
      {
        title: "Responsive Web Design",
        description: "Create websites for all devices.",
        category: "Web Development",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1534670007418-bc92f75680b5",
        instructor: "Emma Wilson",
        duration: "3 weeks",
        lessonsCount: 10,
        price: "Free",
        rating: "4.9",
        reviewCount: 187,
        status: "published"
      },
      {
        title: "Social Media Marketing",
        description: "Market on social platforms effectively.",
        category: "Marketing",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1611926653458-09294b3142bf",
        instructor: "Jessica Clark",
        duration: "4 weeks",
        lessonsCount: 12,
        price: "Free",
        rating: "4.7",
        reviewCount: 142,
        status: "published"
      },
      {
        title: "JavaScript Basics",
        description: "Start with JavaScript programming.",
        category: "Web Development",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a",
        instructor: "Jason Parker",
        duration: "6 weeks",
        lessonsCount: 18,
        price: "Free",
        rating: "4.8",
        reviewCount: 165,
        status: "published"
      },
      {
        title: "Cybersecurity Fundamentals",
        description: "Protect systems from digital attacks.",
        category: "IT & Software",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1563206767-5b18f218e8de",
        instructor: "David Martinez",
        duration: "5 weeks",
        lessonsCount: 15,
        price: "Free",
        rating: "4.9",
        reviewCount: 178,
        status: "published"
      },
      {
        title: "Digital Photography",
        description: "Master digital photography skills.",
        category: "Photography",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1553825250-cc0d9e3cb0c3",
        instructor: "Linda Carter",
        duration: "4 weeks",
        lessonsCount: 12,
        price: "Free",
        rating: "4.7",
        reviewCount: 134,
        status: "published"
      },
      {
        title: "Content Creation",
        description: "Create engaging digital content.",
        category: "Marketing",
        level: "Intermediate",
        imageUrl: "https://images.unsplash.com/photo-1499750310107-5fef28a66643",
        instructor: "Patricia Mills",
        duration: "3 weeks",
        lessonsCount: 9,
        price: "Free",
        rating: "4.6",
        reviewCount: 112,
        status: "published"
      },
      {
        title: "SQL Basics",
        description: "Learn database management and SQL.",
        category: "IT & Software",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1570126618409-e3ab68494db7",
        instructor: "Robert Kennedy",
        duration: "4 weeks",
        lessonsCount: 12,
        price: "Free",
        rating: "4.8",
        reviewCount: 145,
        status: "published"
      },
      {
        title: "UX Design Fundamentals",
        description: "Learn designing great user experiences.",
        category: "Design",
        level: "Intermediate",
        imageUrl: "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c",
        instructor: "Rebecca Thompson",
        duration: "5 weeks",
        lessonsCount: 15,
        price: "Free",
        rating: "4.7",
        reviewCount: 131,
        status: "published"
      },
      {
        title: "3D Modeling Basics",
        description: "Create basic 3D models.",
        category: "Design",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1626544827763-d516dce335e2",
        instructor: "Chris Walters",
        duration: "6 weeks",
        lessonsCount: 18,
        price: "Free",
        rating: "4.6",
        reviewCount: 118,
        status: "published"
      },
      {
        title: "SEO Fundamentals",
        description: "Optimize for search engines.",
        category: "Marketing",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1571091718767-18b5b1457add",
        instructor: "Thomas Robinson",
        duration: "3 weeks",
        lessonsCount: 9,
        price: "Free",
        rating: "4.8",
        reviewCount: 156,
        status: "published"
      },
      {
        title: "Video Editing",
        description: "Edit videos professionally.",
        category: "Photography",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1574717024453-e40aabc7d1eb",
        instructor: "Laura Fisher",
        duration: "4 weeks",
        lessonsCount: 12,
        price: "Free",
        rating: "4.7",
        reviewCount: 129,
        status: "published"
      },
      {
        title: "Game Development",
        description: "Create games with popular engines.",
        category: "Development",
        level: "Intermediate",
        imageUrl: "https://images.unsplash.com/photo-1511882150382-421056c89033",
        instructor: "Mark Reynolds",
        duration: "7 weeks",
        lessonsCount: 21,
        price: "Free",
        rating: "4.9",
        reviewCount: 182,
        status: "published"
      },
      {
        title: "Email Marketing",
        description: "Create effective email campaigns.",
        category: "Marketing",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1596526131083-e8c633c948d2",
        instructor: "Emily Jackson",
        duration: "3 weeks",
        lessonsCount: 9,
        price: "Free",
        rating: "4.6",
        reviewCount: 115,
        status: "published"
      },
      {
        title: "Personal Finance",
        description: "Manage personal finances effectively.",
        category: "Business",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44",
        instructor: "Steven Harrison",
        duration: "4 weeks",
        lessonsCount: 12,
        price: "Free",
        rating: "4.8",
        reviewCount: 152,
        status: "published"
      },
      {
        title: "Public Speaking",
        description: "Deliver powerful presentations.",
        category: "Personal Development",
        level: "Beginner",
        imageUrl: "https://images.unsplash.com/photo-1520263115673-610416f52ab6",
        instructor: "Natalie Brooks",
        duration: "3 weeks",
        lessonsCount: 9,
        price: "Free",
        rating: "4.9",
        reviewCount: 174,
        status: "published"
      },
      {
        title: "IoT Basics",
        description: "Learn about Internet of Things.",
        category: "Technology",
        level: "Intermediate",
        imageUrl: "https://images.unsplash.com/photo-1558346490-a72e53ae2d4f",
        instructor: "Alex Morgan",
        duration: "5 weeks",
        lessonsCount: 15,
        price: "Free",
        rating: "4.7",
        reviewCount: 138,
        status: "published"
      }
    ];
    
    const webDevCourseObj = this.createCourse(webDevCourse);
    const dataScienceCourseObj = this.createCourse(dataScienceCourse);
    const uxDesignCourseObj = this.createCourse(uxDesignCourse);
    const pythonCourseObj = this.createCourse(pythonBasicsCourse);
    const marketingCourseObj = this.createCourse(digitalMarketingCourse);
    const aiCourseObj = this.createCourse(introToAICourse);
    
    // Create 19 additional free courses
    const freeCourseObjs = freeCourses.map(course => this.createCourse(course));
    
    // Sample modules for Web Development course
    const module1: InsertModule = {
      courseId: webDevCourseObj.id,
      title: "Getting Started",
      position: 1
    };
    
    const module2: InsertModule = {
      courseId: webDevCourseObj.id,
      title: "Building Pages",
      position: 2
    };
    
    const module3: InsertModule = {
      courseId: webDevCourseObj.id,
      title: "JavaScript Essentials",
      position: 3
    };
    
    const moduleObj1 = this.createModule(module1);
    this.createModule(module2);
    this.createModule(module3);
    
    // Sample lessons for first module
    const lesson1: InsertLesson = {
      courseId: webDevCourseObj.id,
      moduleId: moduleObj1.id,
      title: "Course Introduction",
      content: "Welcome to Web Development Fundamentals. In this course, you will learn...",
      videoUrl: "https://example.com/videos/intro.mp4",
      duration: "10:25",
      position: 1
    };
    
    const lesson2: InsertLesson = {
      courseId: webDevCourseObj.id,
      moduleId: moduleObj1.id,
      title: "Introduction to HTML",
      content: "HTML (HyperText Markup Language) is the standard markup language for documents designed to be displayed in a web browser. It defines the structure of web content using a series of elements that tell the browser how to display the content.",
      videoUrl: "https://example.com/videos/html-intro.mp4",
      duration: "15:30",
      position: 2
    };
    
    const lesson1Obj = this.createLesson(lesson1);
    const lesson2Obj = this.createLesson(lesson2);
    
    // Sample quiz for HTML intro lesson
    const quiz1: InsertQuiz = {
      lessonId: lesson2Obj.id,
      title: "HTML Basics Quiz"
    };
    
    const quiz1Obj = this.createQuiz(quiz1);
    
    // Sample quiz questions
    const question1: InsertQuizQuestion = {
      quizId: quiz1Obj.id,
      question: "What does HTML stand for?",
      options: JSON.stringify([
        "HyperText Markup Language",
        "High-level Text Management Language",
        "Hyperlink and Text Markup Language",
        "Home Tool Markup Language"
      ]),
      correctAnswer: "HyperText Markup Language"
    };
    
    const question2: InsertQuizQuestion = {
      quizId: quiz1Obj.id,
      question: "Which tag is used to define an HTML document?",
      options: JSON.stringify([
        "<document>",
        "<web>",
        "<html>",
        "<body>"
      ]),
      correctAnswer: "<html>"
    };
    
    const question3: InsertQuizQuestion = {
      quizId: quiz1Obj.id,
      question: "Which of the following is an example of semantic HTML?",
      options: JSON.stringify([
        "<div>",
        "<span>",
        "<article>",
        "<b>"
      ]),
      correctAnswer: "<article>"
    };
    
    this.createQuizQuestion(question1);
    this.createQuizQuestion(question2);
    this.createQuizQuestion(question3);
    
    // Add modules, lessons and quizzes for all courses
    // Create a simple module and lesson for each free course
    const allCourses = [pythonCourseObj, marketingCourseObj, aiCourseObj, ...freeCourseObjs];
    
    allCourses.forEach(course => {
      // Create a module for this course
      const moduleData = {
        courseId: course.id,
        title: "Course Introduction",
        position: 1
      };
      
      const module = this.createModule(moduleData);
      
      // Create a lesson for this module
      // Generate course-specific backgrounds instead of loading external images
      // We'll use a simple but reliable image generation approach
      
      let backgroundColorCode;
      
      // Assign color codes based on category
      if (course.category === "Web Development") {
        backgroundColorCode = "2563eb"; // Blue
      } else if (course.category === "Data Science") {
        backgroundColorCode = "16a34a"; // Green
      } else if (course.category === "Design") {
        backgroundColorCode = "dc2626"; // Red
      } else if (course.category === "Photography") {
        backgroundColorCode = "6d28d9"; // Purple
      } else if (course.category === "Marketing") {
        backgroundColorCode = "ea580c"; // Orange 
      } else if (course.category === "IT & Software") {
        backgroundColorCode = "475569"; // Slate
      } else if (course.category === "Business") {
        backgroundColorCode = "854d0e"; // Amber
      } else if (course.category === "Technology") {
        backgroundColorCode = "0f766e"; // Teal
      } else if (course.category === "Personal Development") {
        backgroundColorCode = "7e22ce"; // Purple
      } else {
        backgroundColorCode = "2563eb"; // Default blue
      }
      
      // Use a simple but effective approach - store just the color code as the video URL
      // The client will generate the appropriate display with this code
      const imageUrl = backgroundColorCode;
      
      const lessonData = {
        courseId: course.id,
        moduleId: module.id,
        title: "Getting Started",
        content: `Welcome to the course! This lesson will introduce you to ${course.title}. You'll learn the fundamentals and key concepts that will form the foundation for your learning journey.`,
        videoUrl: imageUrl, // Using reliable generated image URLs
        duration: "10:30",
        position: 1
      };
      
      const lesson = this.createLesson(lessonData);
      
      // Create a quiz for this lesson
      const quizData = {
        lessonId: lesson.id,
        title: `${course.title} Quiz`
      };
      
      const quiz = this.createQuiz(quizData);
      
      // Create quiz questions
      this.createQuizQuestion({
        quizId: quiz.id,
        question: "What is this course about?",
        options: JSON.stringify([
          course.description,
          "Web Development",
          "Data Science",
          "None of the above"
        ]),
        correctAnswer: course.description
      });
    });
    
    // Sample enrollments
    const enrollment1: InsertEnrollment = {
      userId: 2, // Student user
      courseId: 1, // Web Development course
      enrollmentDate: new Date(),
      progress: 35,
      isCompleted: false
    };
    
    const enrollment2: InsertEnrollment = {
      userId: 2, // Student user
      courseId: 2, // Data Science course
      enrollmentDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
      progress: 100,
      isCompleted: true
    };
    
    const enrollment3: InsertEnrollment = {
      userId: 2, // Student user
      courseId: 3, // UX Design course
      enrollmentDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // 15 days ago
      progress: 100,
      isCompleted: true
    };
    
    // Add enrollments for free courses
    const enrollment4: InsertEnrollment = {
      userId: 2, // Student user
      courseId: 4, // Python course
      enrollmentDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
      progress: 50,
      isCompleted: false
    };
    
    const enrollment5: InsertEnrollment = {
      userId: 2, // Student user
      courseId: 5, // Digital Marketing course
      enrollmentDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago
      progress: 100,
      isCompleted: true
    };
    
    this.createEnrollment(enrollment1);
    this.createEnrollment(enrollment2);
    this.createEnrollment(enrollment3);
    this.createEnrollment(enrollment4);
    this.createEnrollment(enrollment5);
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }
  
  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...userData, id };
    this.users.set(id, user);
    return user;
  }
  
  // Course operations
  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }
  
  async getAllCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }
  
  async getCoursesByCategory(category: string): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(
      course => course.category === category
    );
  }
  
  async createCourse(courseData: InsertCourse): Promise<Course> {
    const id = this.courseId++;
    const course: Course = { ...courseData, id };
    this.courses.set(id, course);
    return course;
  }
  
  async updateCourse(id: number, courseData: Partial<InsertCourse>): Promise<Course | undefined> {
    const course = this.courses.get(id);
    if (!course) return undefined;
    
    const updatedCourse = { ...course, ...courseData };
    this.courses.set(id, updatedCourse);
    return updatedCourse;
  }
  
  async deleteCourse(id: number): Promise<boolean> {
    return this.courses.delete(id);
  }
  
  // Enrollment operations
  async getEnrollment(userId: number, courseId: number): Promise<Enrollment | undefined> {
    return Array.from(this.enrollments.values()).find(
      enrollment => enrollment.userId === userId && enrollment.courseId === courseId
    );
  }
  
  async getEnrollmentsByUser(userId: number): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(
      enrollment => enrollment.userId === userId
    );
  }
  
  async createEnrollment(enrollmentData: InsertEnrollment): Promise<Enrollment> {
    const id = this.enrollmentId++;
    const enrollment: Enrollment = { 
      ...enrollmentData, 
      id,
      enrollmentDate: enrollmentData.enrollmentDate || new Date(),
      progress: enrollmentData.progress || 0,
      isCompleted: enrollmentData.isCompleted || false
    };
    this.enrollments.set(id, enrollment);
    return enrollment;
  }
  
  async updateEnrollmentProgress(id: number, progress: number): Promise<Enrollment | undefined> {
    const enrollment = this.enrollments.get(id);
    if (!enrollment) return undefined;
    
    const updatedEnrollment = { ...enrollment, progress };
    this.enrollments.set(id, updatedEnrollment);
    return updatedEnrollment;
  }
  
  async completeEnrollment(id: number): Promise<Enrollment | undefined> {
    const enrollment = this.enrollments.get(id);
    if (!enrollment) return undefined;
    
    const updatedEnrollment = { ...enrollment, progress: 100, isCompleted: true };
    this.enrollments.set(id, updatedEnrollment);
    return updatedEnrollment;
  }
  
  // Lesson operations
  async getLesson(id: number): Promise<Lesson | undefined> {
    return this.lessons.get(id);
  }
  
  async getLessonsByCourse(courseId: number): Promise<Lesson[]> {
    return Array.from(this.lessons.values()).filter(
      lesson => lesson.courseId === courseId
    );
  }
  
  async getLessonsByModule(moduleId: number): Promise<Lesson[]> {
    return Array.from(this.lessons.values()).filter(
      lesson => lesson.moduleId === moduleId
    );
  }
  
  async createLesson(lessonData: InsertLesson): Promise<Lesson> {
    const id = this.lessonId++;
    const lesson: Lesson = { 
      ...lessonData, 
      id 
    };
    this.lessons.set(id, lesson);
    return lesson;
  }
  
  // Module operations
  async getModule(id: number): Promise<Module | undefined> {
    return this.modules.get(id);
  }
  
  async getModulesByCourse(courseId: number): Promise<Module[]> {
    return Array.from(this.modules.values()).filter(
      module => module.courseId === courseId
    );
  }
  
  async createModule(moduleData: InsertModule): Promise<Module> {
    const id = this.moduleId++;
    const module: Module = {
      ...moduleData,
      id
    };
    this.modules.set(id, module);
    return module;
  }
  
  // Quiz operations
  async getQuiz(id: number): Promise<Quiz | undefined> {
    return this.quizzes.get(id);
  }
  
  async getQuizByLesson(lessonId: number): Promise<Quiz | undefined> {
    return Array.from(this.quizzes.values()).find(
      quiz => quiz.lessonId === lessonId
    );
  }
  
  async createQuiz(quizData: InsertQuiz): Promise<Quiz> {
    const id = this.quizId++;
    const quiz: Quiz = {
      ...quizData,
      id
    };
    this.quizzes.set(id, quiz);
    return quiz;
  }
  
  // Quiz question operations
  async getQuizQuestions(quizId: number): Promise<QuizQuestion[]> {
    return Array.from(this.quizQuestions.values()).filter(
      question => question.quizId === quizId
    );
  }
  
  async createQuizQuestion(questionData: InsertQuizQuestion): Promise<QuizQuestion> {
    const id = this.questionId++;
    const question: QuizQuestion = { ...questionData, id };
    this.quizQuestions.set(id, question);
    return question;
  }
  
  // Quiz attempt operations
  async getQuizAttempts(userId: number, quizId: number): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values()).filter(
      attempt => attempt.userId === userId && attempt.quizId === quizId
    );
  }
  
  async createQuizAttempt(attemptData: InsertQuizAttempt): Promise<QuizAttempt> {
    const id = this.attemptId++;
    const attempt: QuizAttempt = { 
      ...attemptData, 
      id,
      attemptDate: attemptData.attemptDate || new Date()
    };
    this.quizAttempts.set(id, attempt);
    return attempt;
  }
}

export const storage = new MemStorage();
