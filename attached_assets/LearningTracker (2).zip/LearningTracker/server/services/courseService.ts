import { db } from "../db";
import { courses, type InsertCourse } from "@shared/schema";
import fetch from "node-fetch";
import { eq } from "drizzle-orm";

// Use local mock data file instead of an external API
import path from 'path';
import fs from 'fs';

// Function to fetch courses from the mock data file
export async function fetchCoursesFromAPI() {
  try {
    console.log("Fetching courses from mock data...");
    
    // Read mock data from file
    const filePath = path.join(process.cwd(), 'server', 'mock-data', 'courses.json');
    const fileData = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileData);
    
    if (!data.courses || !Array.isArray(data.courses)) {
      console.error("Unexpected mock data format:", data);
      throw new Error("Invalid mock data format");
    }
    
    console.log(`Fetched ${data.courses.length} courses from mock data`);
    
    // Process the mock data
    return data.courses.map((course: any) => {
      return {
        title: course.title || "Untitled Course",
        description: course.description || "No description available",
        category: course.category || "General",
        level: course.level || "All Levels",
        imageUrl: course.imageUrl || "https://placehold.co/600x400?text=Course",
        instructor: course.instructor || "Various Instructors",
        duration: course.duration || "Self-paced",
        price: course.price || "Free",
        rating: (course.rating || "4.0").toString(),
        reviewCount: parseInt(course.reviewCount) || 0,
        lessonsCount: 10 // Adding default lessons count
      };
    });
  } catch (error) {
    console.error("Error fetching courses from API:", error);
    throw error;
  }
}

// Function to store courses in the database
export async function storeCoursesInDB(coursesData: InsertCourse[]) {
  try {
    console.log(`Storing ${coursesData.length} courses in database...`);
    
    // Store each course, handling potential duplicates by title
    const storedCourses = [];
    
    for (const course of coursesData) {
      try {
        // Check if a course with this title already exists
        const existingCourses = await db.select().from(courses).where(eq(courses.title, course.title));
        
        if (existingCourses && existingCourses.length > 0) {
          console.log(`Course already exists: ${course.title}`);
          storedCourses.push(existingCourses[0]);
        } else {
          // Insert the new course
          const [newCourse] = await db.insert(courses).values(course).returning();
          console.log(`Inserted new course: ${course.title}`);
          storedCourses.push(newCourse);
        }
      } catch (courseError) {
        console.error(`Error storing individual course ${course.title}:`, courseError);
      }
    }
    
    console.log(`Successfully stored ${storedCourses.length} courses in database`);
    return storedCourses;
  } catch (error) {
    console.error("Error storing courses in database:", error);
    throw error;
  }
}

// Function to get all courses from the database
export async function getCoursesFromDB() {
  try {
    return await db.select().from(courses);
  } catch (error) {
    console.error("Error fetching courses from database:", error);
    throw error;
  }
}